THE FIREFOX LOGO IS COPYRIGHTED BY MOZILLA. THESE IMAGES ARE TO BE USED ONLY FOR PERSONAL USE AND NOT SOLD UNDER ANY CIRCUMSTANCES EXCEPT BY MOZILLA. I DO NOT TAKE CREDIT FOR THE CREATION OF THE FIREFOX LOGO, ONLY FOR THE ALTERATIONS I HAVE MADE TO THE BASE LOGO. I CLAIM NO COPYRIGHT OR OTHER RIGHTS BEYOND USE OF THE IMAGE FOR MY DESKTOP ICON. 


How to change on MAC:
1. Right click on Firefox in the applications tab of finder
2. Click get info
3. Drag the .icns of which ever variant you want over the small icon in the top left of the get info window
4. You may have to remove Firefox from your dock/desktop and then drag it out from the applications folder and to the dock/desktop again

How to change on WINDOWS 10:
I’m not entirely sure how to do this on a windows machine correctly so here are two youtube links
https://www.youtube.com/watch?v=es8bZuY2JCs
https://www.youtube.com/watch?time_continue=49&v=DyrczyV03yQ&feature=emb_logo
 